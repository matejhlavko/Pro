package kpro2;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import kpro2.controller.ListingController;
import kpro2.model.Listing;
import kpro2.service.ListingService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

@WebMvcTest(ListingController.class)
public class ListingControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Mock
    private ListingService listingService;

    @InjectMocks
    private ListingController listingController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    // Existing test for deleting a listing
    @Test
    public void testDeleteListing_Success() throws Exception {
        Long listingId = 1L;

        // Mock the service call
        doNothing().when(listingService).deleteListing(listingId);

        // Perform the delete request
        mockMvc.perform(post("/listings/{id}/delete", listingId)
                        .contentType(MediaType.APPLICATION_FORM_URLENCODED))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/listings")); // Adjust the redirect URL as needed

        // Verify that the service method was called
        verify(listingService, times(1)).deleteListing(listingId);
    }

    // New test for retrieving a listing by ID
    @Test
    public void testGetListingById_Success() throws Exception {
        Long listingId = 1L;
        Listing mockListing = new Listing();
        mockListing.setId(listingId);
        mockListing.setDescription("Sample Listing Description");

        // Mock the service call
        when(listingService.findById(listingId)).thenReturn(mockListing);

        // Perform the GET request
        mockMvc.perform(get("/listings/{id}", listingId)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(model().attributeExists("listing"))
                .andExpect(model().attribute("listing", mockListing))
                .andExpect(view().name("listing_detail"));

        verify(listingService, times(1)).findById(listingId);
    }

}
