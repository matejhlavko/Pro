package kpro2.repository;

import kpro2.model.Listing;
import kpro2.model.Pet;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ListingRepository extends JpaRepository<Listing, Long> {
    void deleteByPet(Pet pet);
}
