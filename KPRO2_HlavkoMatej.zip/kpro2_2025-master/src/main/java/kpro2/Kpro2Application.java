package kpro2;

import kpro2.model.Pet;
import kpro2.model.User;
import kpro2.service.PetService;
import kpro2.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class Kpro2Application {

    private final UserService userService;
    private final PetService petService;

    @Autowired
    public Kpro2Application(UserService userService, PetService petService) {
        this.userService = userService;
        this.petService = petService;
    }

    private void addUser(User user) {
        userService.saveUser(user);
    }
private void addPet (Pet pet) {petService.savePet(pet);}

    @Bean
    CommandLineRunner init() {
        return args -> {
            User user = new User();
            user.setName("Admin");
            user.setUsername("admin");
            user.setPassword("heslo");
            user.setRole("ADMIN");
            addUser(user);

            User user2 = new User();
            user2.setName("User");
            user2.setUsername("user");
            user2.setPassword("heslo");
            user2.setRole("USER");
            addUser(user2);

            Pet newPet = new Pet();
            newPet.setName("Bob");
            newPet.setType("Dog");
            newPet.setAge(3);
            newPet.setBreed("Golden Retriever");
            newPet.setDescription("Friendly and energetic dog.");
            addPet(newPet);

            Pet newPet1 = new Pet();
            newPet1.setName("Kevin");
            newPet1.setType("Cat");
            newPet1.setAge(1);
            newPet1.setBreed("Norwegian Forest Cat");
            newPet1.setDescription("Cuddly and active cat.");
            addPet(newPet1);

        };
    }

    public static void main(String[] args) {
        SpringApplication.run(Kpro2Application.class, args);
    }

}
