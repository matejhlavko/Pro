package kpro2.controller;

import kpro2.model.Listing;
import kpro2.model.Message;
import kpro2.model.User;
import kpro2.service.MessageService; // Ensure you have a service for handling messages
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDateTime;

@Controller
public class MessageController {

    private final MessageService messageService;

    @Autowired
    public MessageController(MessageService messageService) {
        this.messageService = messageService;
    }

    @PostMapping("/messages/send")
    public String sendMessage(@RequestParam Long listingId,
                              @RequestParam Long senderId,
                              @RequestParam Long recipientId,
                              @RequestParam String content) {
        Message message = new Message();
        message.setContent(content);
        User sender = messageService.findUserById(senderId);
        User recipient = messageService.findUserById(recipientId);
        Listing listing = messageService.findListingById(listingId);

        message.setSender(sender);
        message.setRecipient(recipient);
        message.setListing(listing);
        message.setSentAt(LocalDateTime.now());

        messageService.saveMessage(message);

        return "redirect:/listings/" + listingId;
    }
}
