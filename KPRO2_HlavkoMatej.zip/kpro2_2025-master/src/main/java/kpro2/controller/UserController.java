package kpro2.controller;

import kpro2.model.Listing;
import kpro2.model.User;
import kpro2.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/users")
public class UserController {

    private final UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping
    public String getAllUsers(Model model) {
        model.addAttribute("users", userService.getAllUsers());
        return "users_list";
    }


    @GetMapping("/new")
    public String showCreateForm(Model model) {
        model.addAttribute("user", new User());
        return "users_form";
    }

    @GetMapping("/listings/form")
    public String showListingForm(Model model) {
        User loggedInUser  = userService.getCurrentUser ();
        model.addAttribute("loggedInUser ", loggedInUser );
        model.addAttribute("listing", new Listing());
        return "listings_form";
    }


    @PostMapping("/save")
    public String saveUser (@ModelAttribute User user) {
        if (user.getId() != null) {
            userService.saveUser (user);
        } else {
            userService.saveUser (user);
        }
        return "redirect:/users";
    }


    @GetMapping("/{id}")
    public String getUserDetail(@PathVariable long id, Model model) {
        User user = userService.getUser(id);
        if (user == null) {
            return "redirect:/users";
        }
        model.addAttribute("user", user);
        return "users_detail";
    }

    @GetMapping("/{id}/edit")
    public String showEditForm(@PathVariable long id, Model model) {
        User user = userService.getUser(id);
        if (user == null) {
            return "redirect:/users";
        }
        model.addAttribute("user", user);
        return "users_form";
    }

    @GetMapping("/{id}/delete")
    public String showDeleteConfirmation(@PathVariable long id, Model model) {
        User user = userService.getUser(id);
        if (user == null) {
            return "redirect:/users";
        }
        model.addAttribute("user", user);
        return "users_delete";
    }

    @PostMapping("/{id}/delete")
    public String confirmDelete(@PathVariable long id) {
        userService.deleteUser(id);
        return "redirect:/users";
    }
}
