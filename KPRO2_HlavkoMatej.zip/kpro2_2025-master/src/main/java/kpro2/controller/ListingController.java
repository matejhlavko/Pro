package kpro2.controller;

import kpro2.model.Listing;
import kpro2.model.Pet;
import kpro2.model.User;
import kpro2.service.ListingService;
import kpro2.service.MessageService;
import kpro2.service.PetService;
import kpro2.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/listings")
public class ListingController {

    private final ListingService listingService;
    private final PetService petService;
    private final UserService userService;
    private final MessageService messageService;

    @Autowired
    public ListingController(
            ListingService listingService,
            PetService petService,
            UserService userService,
            MessageService messageService
    ) {
        this.listingService = listingService;
        this.petService = petService;
        this.userService = userService;
        this.messageService = messageService;
    }


    @GetMapping
    public String listAll(Model model) {
        model.addAttribute("listings", listingService.getAllListings());
        return "home";
    }

    @GetMapping("/new")
    public String newListingForm(Model model) {
        model.addAttribute("listing", new Listing());
        model.addAttribute("pets", petService.getAllPets());
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String username = auth.getName();
        User loggedInUser  = userService.findByUsername(username);
        model.addAttribute("loggedInUser ", loggedInUser ); // Ensure no trailing space
        return "listings_form";
    }


    @PostMapping("/save")
    public String saveListing(@ModelAttribute Listing listing, Authentication authentication) {
        String username = authentication.getName();
        User loggedInUser  = userService.findByUsername(username);
        listing.setListedBy(loggedInUser );
        listingService.saveListing(listing);
        return "redirect:/home";
    }


    @GetMapping("/{id}")
    public String getListing(@PathVariable long id, Model model) {
        Listing listing = listingService.getListing(id);
        if (listing == null) return "redirect:/home";

        model.addAttribute("listing", listing);
        model.addAttribute("messages", messageService.getMessagesByListingId(id));
        model.addAttribute("currentUser", userService.getCurrentUser()); // Must be implemented
        return "listings_detail";
    }


    @GetMapping("/{id}/edit")
    public String editListing(@PathVariable long id, Model model) {
        Listing listing = listingService.getListing(id);
        if (listing == null) return "redirect:/listings";
        model.addAttribute("listing", listing);
        model.addAttribute("pets", petService.getAllPets());
        model.addAttribute("users", userService.getAllUsers());
        return "listings_form";
    }

    @GetMapping("/{id}/delete")
    public String confirmDeleteListing(@PathVariable Long id, Model model) {
        Optional<Listing> optionalListing = listingService.findById(id);
        if (optionalListing.isPresent()) {
            Listing listing = optionalListing.get();
            boolean hasPets = listingService.isListingAssociatedWithPets(id);
            model.addAttribute("listing", listing);
            model.addAttribute("hasPets", hasPets);
            return "listings_delete";
        } else {
            return "redirect:/";
        }
    }




    @PostMapping("/{id}/delete")
    public String deleteListing(@PathVariable long id) {
        listingService.deleteListing(id);
        return "redirect:/listings";
    }

    @GetMapping("/listings/form")
    public String showListingForm(Model model, @RequestParam(required = false) Long id) {
        User loggedInUser  = userService.getCurrentUser ();
        model.addAttribute("loggedInUser ", loggedInUser );

        Optional<Listing> listing;
        if (id != null) {
            listing = listingService.findById(id);
        } else {
            listing = Optional.of(new Listing());
        }
        model.addAttribute("listing", listing);

        List<Pet> pets = petService.findAll();
        model.addAttribute("pets", pets);

        return "listings_form";
    }
}
