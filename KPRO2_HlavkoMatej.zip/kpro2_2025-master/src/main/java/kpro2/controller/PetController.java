package kpro2.controller;

import kpro2.model.Listing;
import kpro2.model.Pet;
import kpro2.model.User;
import kpro2.service.ListingService;
import kpro2.service.PetService;
import kpro2.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/pets")
public class PetController {

    private final PetService petService;
    private final UserService userService;
    private final ListingService listingService;

    @Autowired
    public PetController(PetService petService, UserService userService, ListingService listingService) {
        this.petService = petService;
        this.userService = userService;
        this.listingService = listingService;
    }

    @GetMapping
    public String listPets(Model model) {
        model.addAttribute("pets", petService.getAllPets());
        return "pets_list";
    }

    @GetMapping("/new")
    public String createPetForm(Model model) {
        model.addAttribute("pet", new Pet());
        return "pets_form";
    }

    @PostMapping("/save")
    public String savePet(@ModelAttribute Pet pet) {
        petService.savePet(pet);
        return "redirect:/pets";
    }

    @GetMapping("/{id}")
    public String petDetail(@PathVariable long id, Model model) {
        Pet pet = petService.getPet(id);
        if (pet == null) {
            return "redirect:/pets";
        }

        model.addAttribute("pet", pet);

        Listing listing = listingService.getListingById(id); // Fetch listing by pet ID
        model.addAttribute("listing", listing);

        User currentUser  = userService.getCurrentUser (); // Fetch currently authenticated user
        model.addAttribute("currentUser ", currentUser );

        return "pets_detail";
    }

    @GetMapping("/{id}/edit")
    public String editPet(@PathVariable Long id, Model model) {
        Pet pet = petService.getPet(id);
        if (pet == null) {
            return "redirect:/pets";
        }
        model.addAttribute("pet", pet);
        return "pets_form";
    }

    @GetMapping("/{id}/delete")
    public String deletePetConfirm(@PathVariable Long id, Model model) {
        Pet pet = petService.getPet(id);
        if (pet == null) {
            return "redirect:/pets";
        }
        model.addAttribute("pet", pet);
        return "pets_delete";
    }

    @PostMapping("/{id}/delete")
    public String deletePet(@PathVariable Long id) {
        petService.deletePet(id);
        return "redirect:/pets";
    }
}
