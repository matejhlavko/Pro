package kpro2.controller;

import kpro2.model.Listing;
import kpro2.service.ListingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class HomeController {

    private final ListingService listingService;

    @Autowired
    public HomeController(ListingService listingService) {
        this.listingService = listingService;
    }

    @GetMapping({"/home", "/"})
    public String home(Model model) {
        List<Listing> listings = listingService.getAllListings();
        model.addAttribute("listings", listings);
        return "home";
    }

    @GetMapping("/admin")
    public String admin() {
        return "admin";
    }

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @GetMapping("/403")
    public String forbidden() {
        return "403";
    }
}

