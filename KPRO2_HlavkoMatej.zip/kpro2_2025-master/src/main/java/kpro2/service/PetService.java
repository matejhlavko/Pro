package kpro2.service;

import kpro2.model.Pet;
import java.util.List;

public interface PetService {
    List<Pet> getAllPets();
    Pet getPet(long id);
    void savePet(Pet pet);
    void deletePet(long id);

    List<Pet> findAll();

}
