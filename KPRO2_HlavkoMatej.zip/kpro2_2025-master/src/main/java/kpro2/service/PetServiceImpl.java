package kpro2.service;

import kpro2.model.Pet;
import kpro2.repository.ListingRepository;
import kpro2.repository.PetRepository;
import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PetServiceImpl implements PetService {

    private final PetRepository petRepository;
    private final ListingRepository listingRepository;

    @Autowired
    public PetServiceImpl(PetRepository petRepository, ListingRepository listingRepository) {
        this.petRepository = petRepository;
        this.listingRepository = listingRepository;
    }

    @Override
    public List<Pet> getAllPets() {
        return petRepository.findAll();
    }

    @Override
    public Pet getPet(long id) {
        Optional<Pet> pet = petRepository.findById(id);
        return pet.orElse(null);
    }

    @Override
    public void savePet(Pet pet) {
        petRepository.save(pet);
    }

    @Override
    @Transactional
    public void deletePet(long id) {
        Pet pet = petRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Pet not found"));
        listingRepository.deleteByPet(pet);
        petRepository.delete(pet);
    }

    @Override
    public List<Pet> findAll() {
        return List.of();
    }
}
