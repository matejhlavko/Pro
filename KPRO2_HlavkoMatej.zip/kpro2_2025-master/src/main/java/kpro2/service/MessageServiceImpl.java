package kpro2.service;

import kpro2.model.Message;
import kpro2.repository.MessageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import kpro2.model.User;
import kpro2.model.Listing;
import kpro2.repository.UserRepository;
import kpro2.repository.ListingRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MessageServiceImpl implements MessageService {
    private final MessageRepository messageRepository;  // Assuming you have this
    private final UserRepository userRepository;
    private final ListingRepository listingRepository;
    @Autowired
    public MessageServiceImpl(MessageRepository messageRepository,
                              UserRepository userRepository,
                              ListingRepository listingRepository) {
        this.messageRepository = messageRepository;
        this.userRepository = userRepository;
        this.listingRepository = listingRepository;
    }

    @Override
    public User findUserById(Long id) {
        return userRepository.findById(id).orElse(null);
    }
    @Override
    public Listing findListingById(Long id) {
        return listingRepository.findById(id).orElse(null);
    }

    @Override
    public List<Message> getMessagesByListingId(Long listingId) {
        return messageRepository.findByListingIdOrderBySentAtDesc(listingId);
    }

    @Override
    public void saveMessage(Message message) {
        messageRepository.save(message);
    }
}
