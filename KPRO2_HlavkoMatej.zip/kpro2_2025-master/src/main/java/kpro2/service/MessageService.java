package kpro2.service;

import kpro2.model.Listing;
import kpro2.model.Message;
import kpro2.model.User;

import java.util.List;

public interface MessageService {
    List<Message> getMessagesByListingId(Long listingId);
    void saveMessage(Message message);

    User findUserById(Long senderId);

    Listing findListingById(Long id);
}
