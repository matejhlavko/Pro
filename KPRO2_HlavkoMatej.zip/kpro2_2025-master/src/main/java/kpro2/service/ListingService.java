package kpro2.service;

import kpro2.model.Listing;
import java.util.List;
import java.util.Optional;

public interface ListingService {
    Listing getListingById(Long id);

    List<Listing> getAllListings();
    Listing getListing(long id);
    void saveListing(Listing listing);
    void deleteListing(long id);

    Optional<Listing> findById(Long id);

    boolean isListingAssociatedWithPets(Long id);
}
